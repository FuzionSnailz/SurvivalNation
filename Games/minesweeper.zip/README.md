# 🧨 Minesweeper Game

A classic Minesweeper game built with Python. Playable as a standalone `.exe` on Windows.

---

## 📦 Features

- Adjustable board sizes  
- Sound effects (clicks, explosion, win)  
- Custom icon and GUI  
- Automatic screen resizing  

---

## ▶️ How to Play

- **Left-click**: Reveal a tile  
- **Right-click**: Place/Remove a flag  
- Uncover all non-mine tiles to win  
- Hit a mine? Boom 💥 — game over

To play, simply open the `minesweeper.exe` file.

---

## 🌐 Please Visit Our Sites!

- [thesnzent.com](https://thesnzent.com/)
- [K Marie's Hair](https://kmarieshair.com/)
- [QDEX](https://fuzionsnailz.github.io/QDEX/)
